# Crypto payment verification design

## TON

The verifier uses the TON Center v3 indexed `GET /api/v3/transactions` endpoint. The official API documents filters for `account`, `hash`, `limit`, and time/logical-time ranges, and exposes transaction fields including `finality`, `mc_block_seqno`, `in_msg.destination`, `in_msg.value`, message content, and execution description. The application queries the configured merchant account and does not treat an API response as a payment until all local invariants pass.

A TON payment is accepted only when the transaction is real, the inbound destination is the configured merchant wallet, the value equals the order's exact nanoTON amount, the message is not bounced, execution succeeded, masterchain inclusion and finality are present, and the order-specific reference appears in the inbound message content. The transaction hash is only a lookup hint.

## Bitcoin and Litecoin

Bitcoin uses the Mempool.space REST API and Litecoin uses the Litecoin Space REST API. Both expose transaction details with `vout` outputs, output values, the destination address, and a `status.confirmed` field with block height. The verifier fetches the transaction and current tip height, calculates confirmations as `tip_height - block_height + 1`, requires the configured threshold, sums only outputs paid to the configured merchant wallet, and compares that exact atomic-unit amount with the order's locked quote.

Bitcoin defaults to one confirmation and Litecoin defaults to six. These thresholds are configurable through `BTC_REQUIRED_CONFIRMATIONS` and `LTC_REQUIRED_CONFIRMATIONS`. BTC/LTC standard wallet payments do not reliably preserve a merchant memo on-chain, so checkout obtains a live quote and adds a small order-specific atomic-unit discriminator. The exact displayed amount plus the configured recipient wallet identify the order. The database also enforces transaction-ID uniqueness across orders.

BTC/LTC quotes are derived from the live TON/BTC/LTC USD prices returned by CoinGecko at checkout and expire after 15 minutes by default. The quote, payment method, exact atomic amount, and expiry are stored in SQLite before the customer is shown payment instructions. Payments received after expiry are rejected.

## Sources

- [1] [TON Center API v3 — Get transactions](https://docs.ton.org/api/v3/blockchain-data/get-transactions) — official query and response fields.
- [2] [TON Docs — Payment processing overview](https://docs.ton.org/applications/payments/overview) — payment monitoring and masterchain finality guidance.
- [3] [TON Console — Transaction tracking](https://docs.tonconsole.com/tonapi/cookbook/transaction-tracking/) — transaction lookup considerations for message hashes.
- [4] [TON Docs — Messages and transactions](https://docs.ton.org/foundations/messages/overview) — transaction finality after masterchain reference.
- [5] [Mempool.space REST API](https://mempool.space/docs/api/rest) — Bitcoin address/transaction/output/confirmation fields.
- [6] [Litecoin Space REST API](https://litecoinspace.org/docs/api/rest) — Litecoin address/transaction/output/confirmation fields.
- [7] [Bitcoin Developer Guide — Payment processing](https://developer.bitcoin.org/devguide/payment_processing.html) — exact recipient payment verification and confirmation before fulfilment.
