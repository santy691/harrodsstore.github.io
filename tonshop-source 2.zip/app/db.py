from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import aiosqlite

from .security import PhraseRecord, encrypt_phrase, phrase_digest


@dataclass(slots=True)
class Category:
    id: int
    name: str
    parent_id: int | None
    product_count: int = 0


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(slots=True)
class Product:
    id: int
    name: str
    description: str
    image_url: str | None
    price_gbp_pence: int
    sku: str
    category_id: int | None
    subcategory_id: int | None
    featured: bool
    stock: int
    reserved_stock: int

    @property
    def available_stock(self) -> int:
        return max(0, self.stock - self.reserved_stock)


@dataclass(slots=True)
class CartLine:
    product: Product
    quantity: int
    line_total_gbp_pence: int


@dataclass(slots=True)
class Order:
    id: int
    user_id: int
    delivery_address: str
    total_nano: int
    payment_method: str
    payment_amount_atomic: int
    payment_symbol: str
    payment_expires_at: str | None
    payment_reference: str
    status: str
    payment_status: str
    payment_tx_hash: str | None
    created_at: str


class Database:
    def __init__(self, path: Path):
        self.path = path

    async def _connect(self) -> aiosqlite.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = await aiosqlite.connect(self.path)
        conn.row_factory = aiosqlite.Row
        await conn.execute("PRAGMA foreign_keys = ON")
        await conn.execute("PRAGMA busy_timeout = 5000")
        return conn

    async def init(self) -> None:
        conn = await self._connect()
        try:
            await conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    description TEXT NOT NULL,
                    image_url TEXT,
                    price_nano INTEGER NOT NULL CHECK(price_nano > 0),
                    price_gbp_pence INTEGER NOT NULL DEFAULT 0 CHECK(price_gbp_pence >= 0),
                    sku TEXT NOT NULL DEFAULT '',
                    category_id INTEGER,
                    subcategory_id INTEGER,
                    featured INTEGER NOT NULL DEFAULT 0,
                    stock INTEGER NOT NULL CHECK(stock >= 0),
                    reserved_stock INTEGER NOT NULL DEFAULT 0 CHECK(reserved_stock >= 0),
                    active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    parent_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
                    UNIQUE(name, parent_id)
                );
                CREATE TABLE IF NOT EXISTS catalogue_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS cart_items (
                    user_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
                    quantity INTEGER NOT NULL CHECK(quantity > 0),
                    PRIMARY KEY(user_id, product_id)
                );
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    telegram_user_id INTEGER NOT NULL,
                    delivery_address TEXT NOT NULL,
                    total_nano INTEGER NOT NULL CHECK(total_nano > 0),
                    payment_method TEXT NOT NULL DEFAULT 'ton',
                    payment_amount_atomic INTEGER NOT NULL DEFAULT 0,
                    payment_symbol TEXT NOT NULL DEFAULT 'TON',
                    payment_expires_at TEXT,
                    payment_reference TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL DEFAULT 'pending_payment',
                    payment_status TEXT NOT NULL DEFAULT 'pending',
                    payment_tx_hash TEXT UNIQUE,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS order_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
                    product_id INTEGER,
                    product_name TEXT NOT NULL,
                    unit_price_nano INTEGER NOT NULL,
                    quantity INTEGER NOT NULL,
                    line_total_nano INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS user_market_phrases (
                    telegram_user_id INTEGER PRIMARY KEY,
                    encrypted_phrase TEXT NOT NULL,
                    salt BLOB NOT NULL,
                    phrase_digest BLOB NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(telegram_user_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_orders_pending ON orders(payment_status, created_at);
                """
            )
            await self._migrate_orders(conn)
            await self._migrate_products(conn)
            await conn.commit()
        finally:
            await conn.close()

    @staticmethod
    async def _migrate_orders(conn: aiosqlite.Connection) -> None:
        cursor = await conn.execute("PRAGMA table_info(orders)")
        columns = {row["name"] for row in await cursor.fetchall()}
        migrations = {
            "payment_method": "TEXT NOT NULL DEFAULT 'ton'",
            "payment_amount_atomic": "INTEGER NOT NULL DEFAULT 0",
            "payment_symbol": "TEXT NOT NULL DEFAULT 'TON'",
            "payment_expires_at": "TEXT",
        }
        for column, definition in migrations.items():
            if column not in columns:
                await conn.execute(f"ALTER TABLE orders ADD COLUMN {column} {definition}")

    @staticmethod
    async def _migrate_products(conn: aiosqlite.Connection) -> None:
        cursor = await conn.execute("PRAGMA table_info(products)")
        columns = {row["name"] for row in await cursor.fetchall()}
        if "price_gbp_pence" not in columns:
            await conn.execute("ALTER TABLE products ADD COLUMN price_gbp_pence INTEGER NOT NULL DEFAULT 0")
        migrations = {
            "sku": "TEXT NOT NULL DEFAULT ''",
            "category_id": "INTEGER",
            "subcategory_id": "INTEGER",
            "featured": "INTEGER NOT NULL DEFAULT 0",
        }
        for column, definition in migrations.items():
            if column not in columns:
                await conn.execute(f"ALTER TABLE products ADD COLUMN {column} {definition}")

    @staticmethod
    def _product(row: aiosqlite.Row) -> Product:
        return Product(
            id=row["id"], name=row["name"], description=row["description"],
            image_url=row["image_url"], price_gbp_pence=row["price_gbp_pence"],
            sku=row["sku"] or f"ITEM-{row['id']:04d}", category_id=row["category_id"],
            subcategory_id=row["subcategory_id"], featured=bool(row["featured"]),
            stock=row["stock"], reserved_stock=row["reserved_stock"],
        )

    @staticmethod
    def _order(row: aiosqlite.Row) -> Order:
        return Order(
            id=row["id"], user_id=row["telegram_user_id"],
            delivery_address=row["delivery_address"], total_nano=row["total_nano"],
            payment_method=row["payment_method"] or "ton",
            payment_amount_atomic=row["payment_amount_atomic"] or row["total_nano"],
            payment_symbol=row["payment_symbol"] or "TON",
            payment_expires_at=row["payment_expires_at"],
            payment_reference=row["payment_reference"], status=row["status"],
            payment_status=row["payment_status"], payment_tx_hash=row["payment_tx_hash"],
            created_at=row["created_at"],
        )

    async def list_categories(self, parent_id: int | None = None) -> list[Category]:
        conn = await self._connect()
        try:
            cursor = await conn.execute(
                """SELECT c.id, c.name, c.parent_id, COUNT(p.id) AS product_count
                   FROM categories c LEFT JOIN products p ON (p.category_id=c.id OR p.subcategory_id=c.id) AND p.active=1
                   WHERE c.parent_id IS ? GROUP BY c.id ORDER BY c.id""", (parent_id,)
            )
            return [Category(row["id"], row["name"], row["parent_id"], row["product_count"]) for row in await cursor.fetchall()]
        finally:
            await conn.close()

    async def get_category(self, category_id: int) -> Category | None:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT id, name, parent_id FROM categories WHERE id=?", (category_id,))
            row = await cursor.fetchone()
            return Category(row["id"], row["name"], row["parent_id"]) if row else None
        finally:
            await conn.close()

    async def ensure_category(self, name: str, parent_id: int | None = None) -> int:
        conn = await self._connect()
        try:
            await conn.execute("INSERT OR IGNORE INTO categories(name, parent_id) VALUES(?,?)", (name.strip()[:120], parent_id))
            cursor = await conn.execute("SELECT id FROM categories WHERE name=? AND parent_id IS ?", (name.strip()[:120], parent_id))
            row = await cursor.fetchone()
            await conn.commit()
            if not row:
                raise RuntimeError("Category could not be created.")
            return int(row["id"])
        finally:
            await conn.close()

    async def rename_category(self, category_id: int, name: str) -> bool:
        conn = await self._connect()
        try:
            cursor = await conn.execute("UPDATE categories SET name=? WHERE id=?", (name.strip()[:120], category_id))
            await conn.commit()
            return cursor.rowcount > 0
        finally:
            await conn.close()

    async def seed_placeholder_catalogue(self) -> tuple[int, int, int]:
        from .catalogue import CATEGORY_GROUPS, iter_seed_products

        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT value FROM catalogue_meta WHERE key='placeholder_seeded'")
            if await cursor.fetchone():
                category_count = await conn.execute("SELECT COUNT(*) AS n FROM categories WHERE parent_id IS NULL")
                subcategory_count = await conn.execute("SELECT COUNT(*) AS n FROM categories WHERE parent_id IS NOT NULL")
                product_count = await conn.execute("SELECT COUNT(*) AS n FROM products")
                return (int((await category_count.fetchone())["n"]), int((await subcategory_count.fetchone())["n"]), int((await product_count.fetchone())["n"]))
            await conn.execute("BEGIN IMMEDIATE")
            category_ids: dict[str, int] = {}
            subcategory_ids: dict[tuple[str, str], int] = {}
            for category, subcategories in CATEGORY_GROUPS.items():
                await conn.execute("INSERT INTO categories(name, parent_id) VALUES(?, NULL)", (category,))
                cursor = await conn.execute("SELECT id FROM categories WHERE name=? AND parent_id IS NULL", (category,))
                category_id = int((await cursor.fetchone())["id"])
                category_ids[category] = category_id
                for subcategory in subcategories:
                    await conn.execute("INSERT INTO categories(name, parent_id) VALUES(?,?)", (subcategory, category_id))
                    cursor = await conn.execute("SELECT id FROM categories WHERE name=? AND parent_id=?", (subcategory, category_id))
                    subcategory_ids[(category, subcategory)] = int((await cursor.fetchone())["id"])
            for item in iter_seed_products():
                timestamp = now_iso()
                await conn.execute(
                    """INSERT INTO products(name, description, image_url, price_nano, price_gbp_pence, sku, category_id, subcategory_id, featured, stock, created_at, updated_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (item.name, item.description, item.image_url, item.price_gbp_pence, item.price_gbp_pence, item.sku, category_ids[item.category], subcategory_ids[(item.category, item.subcategory)], int(item.featured), item.stock, timestamp, timestamp),
                )
            await conn.execute("INSERT INTO catalogue_meta(key, value) VALUES('placeholder_seeded', '1')")
            await conn.commit()
            return len(CATEGORY_GROUPS), sum(len(x) for x in CATEGORY_GROUPS.values()), sum(1 for _ in iter_seed_products())
        except Exception:
            await conn.rollback()
            raise
        finally:
            await conn.close()

    async def export_catalogue_rows(self) -> list[dict[str, object]]:
        conn = await self._connect()
        try:
            cursor = await conn.execute(
                """SELECT p.id, p.sku, p.name, p.description, c.name AS category, s.name AS subcategory,
                   p.price_gbp_pence, p.stock, p.image_url, p.active, p.featured
                   FROM products p LEFT JOIN categories c ON p.category_id=c.id
                   LEFT JOIN categories s ON p.subcategory_id=s.id ORDER BY p.id"""
            )
            return [{
                "id": row["id"], "sku": row["sku"], "name": row["name"], "description": row["description"],
                "category": row["category"] or "", "subcategory": row["subcategory"] or "",
                "price_gbp": f"{row['price_gbp_pence'] / 100:.2f}", "stock": row["stock"],
                "image_url": row["image_url"] or "", "active": row["active"], "featured": row["featured"],
            } for row in await cursor.fetchall()]
        finally:
            await conn.close()

    async def upsert_catalogue_row(self, row: dict[str, object]) -> int:
        conn = await self._connect()
        try:
            await conn.execute("BEGIN IMMEDIATE")
            category_name = str(row.get("category") or "Miscellaneous").strip()[:120]
            subcategory_name = str(row.get("subcategory") or "Useful Finds").strip()[:120]
            await conn.execute("INSERT OR IGNORE INTO categories(name, parent_id) VALUES(?, NULL)", (category_name,))
            cursor = await conn.execute("SELECT id FROM categories WHERE name=? AND parent_id IS NULL", (category_name,))
            category_id = int((await cursor.fetchone())["id"])
            await conn.execute("INSERT OR IGNORE INTO categories(name, parent_id) VALUES(?,?)", (subcategory_name, category_id))
            cursor = await conn.execute("SELECT id FROM categories WHERE name=? AND parent_id=?", (subcategory_name, category_id))
            subcategory_id = int((await cursor.fetchone())["id"])
            sku = str(row.get("sku") or "").strip()[:80]
            if not sku:
                raise ValueError("CSV row is missing SKU.")
            values = (str(row["name"])[:120], str(row["description"])[:1000], str(row.get("image_url") or "") or None, int(row["price_gbp_pence"]), int(row["price_gbp_pence"]), category_id, subcategory_id, int(row.get("featured", 0)), int(row["stock"]), int(row.get("active", 1)), now_iso())
            existing = await conn.execute("SELECT id FROM products WHERE sku=?", (sku,))
            found = await existing.fetchone()
            if found:
                product_id = int(found["id"])
                await conn.execute("""UPDATE products SET name=?, description=?, image_url=?, price_nano=?, price_gbp_pence=?,
                    category_id=?, subcategory_id=?, featured=?, stock=?, active=?, updated_at=? WHERE id=?""", values + (product_id,))
            else:
                cursor = await conn.execute("""INSERT INTO products(name, description, image_url, price_nano, price_gbp_pence,
                    sku, category_id, subcategory_id, featured, stock, active, created_at, updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", values[:5] + (sku,) + values[5:] + (values[-1],))
                product_id = int(cursor.lastrowid)
            await conn.commit()
            return product_id
        except Exception:
            await conn.rollback()
            raise
        finally:
            await conn.close()

    async def list_products(self, include_inactive: bool = False, category_id: int | None = None) -> list[Product]:
        conn = await self._connect()
        try:
            query = "SELECT * FROM products"
            args: list[object] = []
            conditions: list[str] = []
            if not include_inactive:
                conditions.append("active = 1")
            if category_id is not None:
                conditions.append("(category_id = ? OR subcategory_id = ?)")
                args.extend([category_id, category_id])
            if conditions:
                query += " WHERE " + " AND ".join(conditions)
            query += " ORDER BY id DESC"
            cursor = await conn.execute(query, args)
            return [self._product(row) for row in await cursor.fetchall()]
        finally:
            await conn.close()

    async def get_product(self, product_id: int) -> Product | None:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT * FROM products WHERE id = ?", (product_id,))
            row = await cursor.fetchone()
            return self._product(row) if row else None
        finally:
            await conn.close()

    async def add_product(self, name: str, description: str, image_url: str | None, price_gbp_pence: int, stock: int, sku: str = "", category_id: int | None = None, subcategory_id: int | None = None, featured: bool = False) -> int:
        conn = await self._connect()
        try:
            timestamp = now_iso()
            cursor = await conn.execute(
                "INSERT INTO products(name, description, image_url, price_nano, price_gbp_pence, sku, category_id, subcategory_id, featured, stock, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (name, description, image_url, price_gbp_pence, price_gbp_pence, sku, category_id, subcategory_id, int(featured), stock, timestamp, timestamp),
            )
            await conn.commit()
            if cursor.lastrowid is None:
                raise RuntimeError("Product insert did not return an ID.")
            return int(cursor.lastrowid)
        finally:
            await conn.close()

    async def edit_product(self, product_id: int, name: str, description: str, image_url: str | None, price_gbp_pence: int, stock: int, sku: str | None = None, category_id: int | None = None, subcategory_id: int | None = None, featured: bool | None = None) -> bool:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT reserved_stock FROM products WHERE id = ?", (product_id,))
            row = await cursor.fetchone()
            if not row or stock < row["reserved_stock"]:
                return False
            await conn.execute(
                """UPDATE products SET name=?, description=?, image_url=?, price_nano=?, price_gbp_pence=?,
                   stock=?, sku=COALESCE(?, sku), category_id=COALESCE(?, category_id),
                   subcategory_id=COALESCE(?, subcategory_id), featured=COALESCE(?, featured), updated_at=? WHERE id=?""",
                (name, description, image_url, price_gbp_pence, price_gbp_pence, stock, sku, category_id, subcategory_id, int(featured) if featured is not None else None, now_iso(), product_id),
            )
            await conn.commit()
            return True
        finally:
            await conn.close()

    async def delete_product(self, product_id: int) -> bool:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT reserved_stock FROM products WHERE id = ?", (product_id,))
            row = await cursor.fetchone()
            if not row or row["reserved_stock"] > 0:
                return False
            await conn.execute("UPDATE products SET active = 0, updated_at = ? WHERE id = ?", (now_iso(), product_id))
            await conn.commit()
            return True
        finally:
            await conn.close()

    async def set_stock(self, product_id: int, stock: int) -> bool:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT reserved_stock FROM products WHERE id = ?", (product_id,))
            row = await cursor.fetchone()
            if not row or stock < row["reserved_stock"]:
                return False
            await conn.execute("UPDATE products SET stock=?, updated_at=? WHERE id=?", (stock, now_iso(), product_id))
            await conn.commit()
            return True
        finally:
            await conn.close()

    async def set_product_flags(self, product_id: int, active: bool, featured: bool) -> bool:
        conn = await self._connect()
        try:
            cursor = await conn.execute("UPDATE products SET active=?, featured=?, updated_at=? WHERE id=?", (int(active), int(featured), now_iso(), product_id))
            await conn.commit()
            return cursor.rowcount > 0
        finally:
            await conn.close()

    async def get_cart(self, user_id: int) -> list[CartLine]:
        conn = await self._connect()
        try:
            cursor = await conn.execute(
                """SELECT p.*, c.quantity FROM cart_items c JOIN products p ON p.id = c.product_id
                   WHERE c.user_id = ? AND p.active = 1 ORDER BY p.id""", (user_id,)
            )
            lines = []
            for row in await cursor.fetchall():
                product = self._product(row)
                quantity = row["quantity"]
                lines.append(CartLine(product, quantity, product.price_gbp_pence * quantity))
            return lines
        finally:
            await conn.close()

    async def change_cart(self, user_id: int, product_id: int, delta: int) -> tuple[bool, str]:
        conn = await self._connect()
        try:
            await conn.execute("BEGIN IMMEDIATE")
            cursor = await conn.execute("SELECT * FROM products WHERE id = ? AND active = 1", (product_id,))
            row = await cursor.fetchone()
            if not row:
                await conn.rollback()
                return False, "Product not found."
            if row["price_gbp_pence"] <= 0:
                await conn.rollback()
                return False, "This product needs a GBP price before it can be purchased."
            available = row["stock"] - row["reserved_stock"]
            cursor = await conn.execute("SELECT quantity FROM cart_items WHERE user_id=? AND product_id=?", (user_id, product_id))
            current_row = await cursor.fetchone()
            current = current_row["quantity"] if current_row else 0
            target = current + delta
            if target > available:
                await conn.rollback()
                return False, f"Only {available} available."
            if target <= 0:
                await conn.execute("DELETE FROM cart_items WHERE user_id=? AND product_id=?", (user_id, product_id))
            elif current:
                await conn.execute("UPDATE cart_items SET quantity=? WHERE user_id=? AND product_id=?", (target, user_id, product_id))
            else:
                await conn.execute("INSERT INTO cart_items(user_id, product_id, quantity) VALUES(?,?,?)", (user_id, product_id, target))
            await conn.commit()
            return True, "Cart updated."
        except Exception:
            await conn.rollback()
            raise
        finally:
            await conn.close()

    async def clear_cart(self, user_id: int) -> None:
        conn = await self._connect()
        try:
            await conn.execute("DELETE FROM cart_items WHERE user_id = ?", (user_id,))
            await conn.commit()
        finally:
            await conn.close()

    async def create_order(
        self,
        user_id: int,
        address: str,
        payment_method: str = "ton",
        payment_amount_atomic: int | None = None,
        payment_symbol: str | None = None,
        payment_expires_at: str | None = None,
    ) -> Order:
        conn = await self._connect()
        try:
            await conn.execute("BEGIN IMMEDIATE")
            payment_method = payment_method.lower().strip()
            if payment_method not in {"ton", "btc", "ltc"}:
                raise ValueError("Unsupported payment method.")
            cursor = await conn.execute(
                """SELECT p.*, c.quantity FROM cart_items c JOIN products p ON p.id=c.product_id
                   WHERE c.user_id=? AND p.active=1 ORDER BY p.id""", (user_id,)
            )
            rows = await cursor.fetchall()
            if not rows:
                raise ValueError("Your cart is empty.")
            total_gbp_pence = 0
            for row in rows:
                if row["stock"] - row["reserved_stock"] < row["quantity"]:
                    raise ValueError(f"Not enough stock for {row['name']}.")
                if row["price_gbp_pence"] <= 0:
                    raise ValueError(f"{row['name']} does not have a GBP price yet.")
                total_gbp_pence += row["price_gbp_pence"] * row["quantity"]
            reference = f"TS-{secrets.token_hex(5).upper()}"
            amount_atomic = payment_amount_atomic if payment_amount_atomic is not None else total_gbp_pence
            payment_symbol = payment_symbol or {"ton": "TON", "btc": "BTC", "ltc": "LTC"}[payment_method]
            if payment_method in {"btc", "ltc"}:
                amount_atomic += 1 + int(reference[-4:], 16) % 10_000
                while True:
                    collision_cursor = await conn.execute(
                        "SELECT id FROM orders WHERE payment_method=? AND payment_amount_atomic=? AND status='pending_payment'",
                        (payment_method, amount_atomic),
                    )
                    if not await collision_cursor.fetchone():
                        break
                    amount_atomic += 1
            timestamp = now_iso()
            cursor = await conn.execute(
                """INSERT INTO orders(
                    telegram_user_id, delivery_address, total_nano, payment_method,
                    payment_amount_atomic, payment_symbol, payment_expires_at,
                    payment_reference, created_at, updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (user_id, address, total_gbp_pence, payment_method, amount_atomic, payment_symbol, payment_expires_at, reference, timestamp, timestamp),
            )
            if cursor.lastrowid is None:
                raise RuntimeError("Order insert did not return an ID.")
            order_id = int(cursor.lastrowid)
            for row in rows:
                qty = row["quantity"]
                await conn.execute(
                    """INSERT INTO order_items(order_id, product_id, product_name, unit_price_nano, quantity, line_total_nano)
                       VALUES(?,?,?,?,?,?)""", (order_id, row["id"], row["name"], row["price_gbp_pence"], qty, row["price_gbp_pence"] * qty)
                )
                await conn.execute("UPDATE products SET reserved_stock = reserved_stock + ? WHERE id = ?", (qty, row["id"]))
            await conn.execute("DELETE FROM cart_items WHERE user_id = ?", (user_id,))
            await conn.commit()
            created_order = await self.get_order(order_id, user_id)
            if created_order is None:
                raise RuntimeError("Order was created but could not be reloaded.")
            return created_order
        except Exception:
            await conn.rollback()
            raise
        finally:
            await conn.close()

    async def get_order(self, order_id: int, user_id: int | None = None) -> Order | None:
        conn = await self._connect()
        try:
            query = "SELECT * FROM orders WHERE id = ?"
            args: list[object] = [order_id]
            if user_id is not None:
                query += " AND telegram_user_id = ?"
                args.append(user_id)
            cursor = await conn.execute(query, args)
            row = await cursor.fetchone()
            return self._order(row) if row else None
        finally:
            await conn.close()

    async def get_order_items(self, order_id: int) -> list[aiosqlite.Row]:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT * FROM order_items WHERE order_id=? ORDER BY id", (order_id,))
            return list(await cursor.fetchall())
        finally:
            await conn.close()

    async def list_user_orders(self, user_id: int, limit: int = 20) -> list[Order]:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT * FROM orders WHERE telegram_user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))
            return [self._order(row) for row in await cursor.fetchall()]
        finally:
            await conn.close()

    async def list_pending_orders(self, limit: int = 100) -> list[Order]:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT * FROM orders WHERE payment_status='pending' AND status='pending_payment' ORDER BY id LIMIT ?", (limit,))
            return [self._order(row) for row in await cursor.fetchall()]
        finally:
            await conn.close()

    async def mark_paid(self, order_id: int, tx_hash: str) -> tuple[bool, str]:
        conn = await self._connect()
        try:
            await conn.execute("BEGIN IMMEDIATE")
            cursor = await conn.execute("SELECT * FROM orders WHERE id=?", (order_id,))
            order = await cursor.fetchone()
            if not order:
                await conn.rollback()
                return False, "Order not found."
            if order["payment_status"] == "paid":
                return True, "already_paid"
            cursor = await conn.execute("SELECT id FROM orders WHERE payment_tx_hash=?", (tx_hash,))
            if await cursor.fetchone():
                await conn.rollback()
                return False, "This transaction is already linked to another order."
            cursor = await conn.execute("SELECT * FROM order_items WHERE order_id=?", (order_id,))
            items = await cursor.fetchall()
            for item in items:
                stock_cursor = await conn.execute("SELECT stock, reserved_stock FROM products WHERE id=?", (item["product_id"],))
                product = await stock_cursor.fetchone()
                if not product or product["stock"] < item["quantity"] or product["reserved_stock"] < item["quantity"]:
                    await conn.rollback()
                    return False, "Stock changed before payment confirmation."
            for item in items:
                await conn.execute(
                    "UPDATE products SET stock=stock-?, reserved_stock=reserved_stock-?, updated_at=? WHERE id=?",
                    (item["quantity"], item["quantity"], now_iso(), item["product_id"]),
                )
            await conn.execute(
                "UPDATE orders SET payment_status='paid', status='processing', payment_tx_hash=?, updated_at=? WHERE id=?",
                (tx_hash, now_iso(), order_id),
            )
            await conn.commit()
            return True, "paid"
        except Exception:
            await conn.rollback()
            raise
        finally:
            await conn.close()

    async def set_order_status(self, order_id: int, status: str) -> bool:
        allowed = {"processing", "shipped", "delivered", "cancelled"}
        if status not in allowed:
            return False
        conn = await self._connect()
        try:
            await conn.execute("BEGIN IMMEDIATE")
            cursor = await conn.execute("SELECT payment_status, status FROM orders WHERE id=?", (order_id,))
            order = await cursor.fetchone()
            if not order:
                await conn.rollback()
                return False
            if status == "cancelled" and order["payment_status"] == "pending" and order["status"] != "cancelled":
                items_cursor = await conn.execute("SELECT product_id, quantity FROM order_items WHERE order_id=?", (order_id,))
                for item in await items_cursor.fetchall():
                    await conn.execute(
                        "UPDATE products SET reserved_stock = MAX(0, reserved_stock - ?), updated_at=? WHERE id=?",
                        (item["quantity"], now_iso(), item["product_id"]),
                    )
            await conn.execute("UPDATE orders SET status=?, updated_at=? WHERE id=?", (status, now_iso(), order_id))
            await conn.commit()
            return True
        except Exception:
            await conn.rollback()
            raise
        finally:
            await conn.close()

    async def list_recent_orders(self, limit: int = 30) -> list[Order]:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT * FROM orders ORDER BY id DESC LIMIT ?", (limit,))
            return [self._order(row) for row in await cursor.fetchall()]
        finally:
            await conn.close()

    async def set_market_phrase(self, user_id: int, phrase: str, bot_token: str) -> None:
        salt = secrets.token_bytes(16)
        encrypted = encrypt_phrase(phrase, bot_token)
        digest = phrase_digest(phrase, salt)
        timestamp = now_iso()
        conn = await self._connect()
        try:
            await conn.execute(
                """INSERT INTO user_market_phrases(telegram_user_id, encrypted_phrase, salt, phrase_digest, created_at, updated_at)
                   VALUES(?,?,?,?,?,?)
                   ON CONFLICT(telegram_user_id) DO UPDATE SET encrypted_phrase=excluded.encrypted_phrase,
                   salt=excluded.salt, phrase_digest=excluded.phrase_digest, updated_at=excluded.updated_at""",
                (user_id, encrypted, salt, digest, timestamp, timestamp),
            )
            await conn.commit()
        finally:
            await conn.close()

    async def get_market_phrase(self, user_id: int) -> PhraseRecord | None:
        conn = await self._connect()
        try:
            cursor = await conn.execute("SELECT * FROM user_market_phrases WHERE telegram_user_id=?", (user_id,))
            row = await cursor.fetchone()
            if not row:
                return None
            return PhraseRecord(row["telegram_user_id"], row["encrypted_phrase"], bytes(row["salt"]), bytes(row["phrase_digest"]))
        finally:
            await conn.close()
