from __future__ import annotations

import base64
import hashlib
import hmac
import re
from dataclasses import dataclass

from cryptography.fernet import Fernet, InvalidToken


MIN_PHRASE_LENGTH = 8
MAX_PHRASE_LENGTH = 128


def normalize_phrase(value: str) -> str:
    phrase = " ".join(value.strip().split())
    if not MIN_PHRASE_LENGTH <= len(phrase) <= MAX_PHRASE_LENGTH:
        raise ValueError(f"Your phrase must be between {MIN_PHRASE_LENGTH} and {MAX_PHRASE_LENGTH} characters.")
    if "|" in phrase or "\n" in phrase or "\r" in phrase:
        raise ValueError("Your phrase cannot contain the | character or line breaks.")
    return phrase


def phrase_digest(phrase: str, salt: bytes) -> bytes:
    return hashlib.scrypt(phrase.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)


def _fernet(bot_token: str) -> Fernet:
    key = base64.urlsafe_b64encode(hashlib.sha256(("tonshop-market-phrase:" + bot_token).encode()).digest())
    return Fernet(key)


def encrypt_phrase(phrase: str, bot_token: str) -> str:
    return _fernet(bot_token).encrypt(phrase.encode("utf-8")).decode("ascii")


def decrypt_phrase(ciphertext: str, bot_token: str) -> str:
    try:
        return _fernet(bot_token).decrypt(ciphertext.encode("ascii")).decode("utf-8")
    except (InvalidToken, UnicodeDecodeError, ValueError) as exc:
        raise ValueError("The market phrase cannot be decrypted with the current bot secret.") from exc


def safe_phrase_label(phrase: str) -> str:
    return re.sub(r"[^A-Za-z0-9 ]", "", phrase)[:128]


@dataclass(slots=True)
class PhraseRecord:
    user_id: int
    encrypted_phrase: str
    salt: bytes
    digest: bytes


def verify_phrase(phrase: str, record: PhraseRecord) -> bool:
    return hmac.compare_digest(phrase_digest(phrase, record.salt), record.digest)
