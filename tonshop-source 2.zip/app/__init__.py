"""TON Shop Telegram bot."""
