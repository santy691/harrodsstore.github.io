from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    telegram_bot_token: str = Field(min_length=20)
    admin_telegram_id: int = Field(gt=0)
    ton_wallet_address: str = Field(min_length=10)
    toncenter_api_key: str | None = None
    btc_wallet_address: str | None = None
    ltc_wallet_address: str | None = None
    mini_app_url: str | None = None
    admin_app_url: str | None = None
    db_path: Path = Path("data/shop.db")
    port: int = Field(default=3000, ge=1024, le=65535)
    ton_api_base_url: str = "https://toncenter.com/api/v3"
    btc_api_base_url: str = "https://mempool.space/api"
    ltc_api_base_url: str = "https://litecoinspace.org/api"
    quote_api_base_url: str = "https://api.coingecko.com/api/v3"
    btc_required_confirmations: int = Field(default=1, ge=1, le=100)
    ltc_required_confirmations: int = Field(default=6, ge=1, le=100)
    payment_quote_ttl_minutes: int = Field(default=15, ge=5, le=120)
    payment_poll_seconds: int = Field(default=30, ge=10, le=3600)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
