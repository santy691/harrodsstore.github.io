from __future__ import annotations

import base64
import binascii
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from typing import Any

import httpx

from .config import Settings
from .db import Order


@dataclass(slots=True)
class PaymentCheck:
    ok: bool
    tx_hash: str | None = None
    reason: str = ""


def ton_to_nano(value: str) -> int:
    try:
        amount = Decimal(value.strip()).quantize(Decimal("0.000000001"), rounding=ROUND_DOWN)
    except (InvalidOperation, AttributeError):
        raise ValueError("Price must be a valid TON amount.")
    if amount <= 0:
        raise ValueError("Price must be greater than zero.")
    return int(amount * Decimal(1_000_000_000))


def nano_to_ton(nano: int) -> str:
    return f"{Decimal(nano) / Decimal(1_000_000_000):.9f}".rstrip("0").rstrip(".")


def normalize_address(address: str) -> str:
    value = address.strip()
    if ":" in value and len(value.split(":", 1)[1]) == 64:
        workchain, account = value.split(":", 1)
        return f"{int(workchain)}:{account.lower()}"
    try:
        padded = value + "=" * (-len(value) % 4)
        raw = base64.urlsafe_b64decode(padded)
        if len(raw) >= 34:
            wc = raw[1] if raw[1] < 128 else raw[1] - 256
            return f"{wc}:{raw[2:34].hex()}"
    except (ValueError, binascii.Error):
        pass
    return value.lower()


def _contains_reference(message: Any, reference: str) -> bool:
    serialized = json.dumps(message, ensure_ascii=False, sort_keys=True).lower()
    if reference.lower() in serialized:
        return True
    encoded = reference.encode().hex().lower()
    return encoded in serialized


def _success_fields(transaction: dict[str, Any]) -> bool:
    description = transaction.get("description") or {}
    if description.get("aborted") is True:
        return False
    compute = description.get("compute_ph") or {}
    action = description.get("action") or {}
    if compute.get("success") is False or action.get("success") is False:
        return False
    inbound = transaction.get("in_msg") or {}
    if inbound.get("bounced") is True:
        return False
    return True


class TonVerifier:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.base_url = settings.ton_api_base_url.rstrip("/")
        self.headers = {"X-API-Key": settings.toncenter_api_key} if settings.toncenter_api_key else {}

    async def _transactions(self, *, tx_hash: str | None = None, limit: int = 100, start_utime: int | None = None) -> list[dict[str, Any]]:
        params: dict[str, str | int] = {"account": self.settings.ton_wallet_address, "limit": limit, "sort": "desc"}
        if tx_hash:
            params["hash"] = tx_hash.strip()
        if start_utime:
            params["start_utime"] = start_utime
        url = f"{self.base_url}/transactions"
        async with httpx.AsyncClient(timeout=15, headers=self.headers) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            payload = response.json()
        return payload.get("transactions", [])

    def _check_transaction(self, order: Order, transaction: dict[str, Any]) -> PaymentCheck:
        if order.payment_expires_at and datetime.now(timezone.utc) > datetime.fromisoformat(order.payment_expires_at):
            return PaymentCheck(False, reason="payment quote expired")
        inbound = transaction.get("in_msg") or {}
        destination = inbound.get("destination") or ""
        if normalize_address(destination) != normalize_address(self.settings.ton_wallet_address):
            return PaymentCheck(False, reason="recipient mismatch")
        try:
            value = int(str(inbound.get("value", "0")))
        except (TypeError, ValueError):
            return PaymentCheck(False, reason="invalid amount")
        if value != order.payment_amount_atomic:
            return PaymentCheck(False, reason="amount mismatch")
        if not _success_fields(transaction):
            return PaymentCheck(False, reason="transaction execution failed or bounced")
        try:
            finality = int(transaction.get("finality") or 0)
            masterchain_seqno = int(transaction.get("mc_block_seqno") or 0)
        except (TypeError, ValueError):
            finality = 0
            masterchain_seqno = 0
        if finality <= 0 or masterchain_seqno <= 0:
            return PaymentCheck(False, reason="not finalized")
        if not _contains_reference(inbound.get("message_content") or inbound, order.payment_reference):
            return PaymentCheck(False, reason="order reference missing")
        tx_hash = str(transaction.get("hash") or inbound.get("in_msg_tx_hash") or "").strip()
        if not tx_hash:
            return PaymentCheck(False, reason="transaction hash missing")
        return PaymentCheck(True, tx_hash=tx_hash, reason="verified")

    async def verify_hash(self, order: Order, tx_hash: str) -> PaymentCheck:
        candidate = tx_hash.strip()
        if len(candidate) < 32 or len(candidate) > 128:
            return PaymentCheck(False, reason="invalid transaction hash format")
        try:
            transactions = await self._transactions(tx_hash=candidate, limit=20)
        except (httpx.HTTPError, ValueError):
            return PaymentCheck(False, reason="blockchain lookup unavailable")
        if not transactions:
            return PaymentCheck(False, reason="transaction not found")
        for transaction in transactions:
            result = self._check_transaction(order, transaction)
            if result.ok:
                return result
        return PaymentCheck(False, reason="transaction failed verification")

    async def find_matching_payment(self, order: Order) -> PaymentCheck:
        try:
            from datetime import datetime
            start = int(datetime.fromisoformat(order.created_at).timestamp()) - 300
            transactions = await self._transactions(start_utime=start, limit=100)
        except (httpx.HTTPError, ValueError, OverflowError):
            return PaymentCheck(False, reason="blockchain lookup unavailable")
        for transaction in transactions:
            result = self._check_transaction(order, transaction)
            if result.ok:
                return result
        return PaymentCheck(False, reason="no verified payment yet")
