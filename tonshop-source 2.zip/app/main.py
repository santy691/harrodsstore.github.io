from __future__ import annotations

import asyncio
import contextlib
import logging

from aiohttp import web
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand
from aiogram.fsm.storage.memory import MemoryStorage

from .config import Settings, get_settings
from .crypto import MultiChainPayments, format_atomic
from .db import Database
from .handlers.admin import router as admin_router
from .handlers.catalogue_admin import router as catalogue_admin_router
from .handlers.user import router as user_router
from .web import setup_web_routes

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("tonshop")


async def health_handler(_: web.Request) -> web.Response:
    return web.Response(text="OK")


async def start_health_server(settings: Settings, db: Database, payments: MultiChainPayments) -> web.AppRunner:
    app = web.Application()
    app.router.add_get("/health", health_handler)
    setup_web_routes(app, db, payments, settings)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", settings.port)
    await site.start()
    return runner


async def payment_monitor(bot: Bot, db: Database, payments: MultiChainPayments, settings: Settings) -> None:
    while True:
        try:
            for order in await db.list_pending_orders():
                result = await payments.find_matching_payment(order)
                if not result.ok or not result.tx_hash:
                    continue
                saved, reason = await db.mark_paid(order.id, result.tx_hash)
                if saved and reason == "paid":
                    logger.info("Verified payment for order #%s", order.id)
                    with contextlib.suppress(Exception):
                        await bot.send_message(order.user_id, f"{order.payment_symbol} payment verified on-chain for order #{order.id}. Amount: {format_atomic(order.payment_amount_atomic, order.payment_symbol)} {order.payment_symbol}.")
                    with contextlib.suppress(Exception):
                        await bot.send_message(settings.admin_telegram_id, f"Payment verified for order #{order.id}.")
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Payment monitor iteration failed")
        await asyncio.sleep(settings.payment_poll_seconds)


async def main() -> None:
    settings = get_settings()
    db = Database(settings.db_path)
    await db.init()
    seed_counts = await db.seed_placeholder_catalogue()
    if seed_counts[2]:
        logger.info("Catalogue ready: %s categories, %s subcategories, %s products", *seed_counts)
    payments = MultiChainPayments(settings)
    bot = Bot(settings.telegram_bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dispatcher = Dispatcher(storage=MemoryStorage())
    dispatcher.include_router(admin_router)
    dispatcher.include_router(catalogue_admin_router)
    dispatcher.include_router(user_router)
    await bot.set_my_commands([
        BotCommand(command="start", description="Open the shop"),
        BotCommand(command="shop", description="Browse products"),
        BotCommand(command="cart", description="View your cart"),
        BotCommand(command="orders", description="Order history"),
        BotCommand(command="help", description="Help"),
        BotCommand(command="setphrase", description="Set your market security phrase"),
        BotCommand(command="verify_market", description="Show your market security phrase"),
        BotCommand(command="cancel", description="Cancel current action"),
        BotCommand(command="admin", description="Admin panel"),
        BotCommand(command="admin_export", description="Export catalogue CSV"),
        BotCommand(command="admin_import", description="Import catalogue CSV"),
        BotCommand(command="admin_template", description="Download catalogue CSV template"),
        BotCommand(command="admin_category_add", description="Add catalogue category"),
        BotCommand(command="admin_category_rename", description="Rename catalogue category"),
    ])
    health_runner = await start_health_server(settings, db, payments)
    monitor = asyncio.create_task(payment_monitor(bot, db, payments, settings))
    try:
        logger.info("TON Shop bot started")
        await dispatcher.start_polling(bot, db=db, payments=payments, settings=settings)
    finally:
        monitor.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await monitor
        await health_runner.cleanup()
        await bot.session.close()


def run() -> None:
    asyncio.run(main())


if __name__ == "__main__":
    run()
