from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo

from ..config import Settings
from ..crypto import MultiChainPayments, enabled_methods, format_atomic, payment_address
from ..db import Database, Order
from ..keyboards import (
    cart_controls,
    category_list,
    main_menu,
    payment_controls,
    payment_method_controls,
    product_detail,
    product_list,
)
from ..security import decrypt_phrase, normalize_phrase
from ..states import CheckoutState, PaymentState, SecurityState

router = Router()


async def order_text(order: Order, settings: Settings) -> str:
    address = payment_address(settings, order.payment_method) or "not configured"
    lines = [
        f"<b>Order #{order.id}</b>",
        f"Status: <b>{order.status.replace('_', ' ')}</b>",
        f"Payment: <b>{order.payment_status}</b>",
        f"Catalogue total: <b>£{order.total_nano / 100:.2f}</b>",
        f"Method: <b>{order.payment_symbol}</b>",
        f"Amount: <b>{format_atomic(order.payment_amount_atomic, order.payment_symbol)} {order.payment_symbol}</b>",
        f"Reference: <code>{order.payment_reference}</code>",
    ]
    if order.payment_status != "paid":
        lines.append(f"Send to: <code>{address}</code>")
        if order.payment_expires_at:
            lines.append("This quote expires in 15 minutes. Exact amount and network are required.")
        if order.payment_method == "ton":
            lines.append("Include the reference as the TON transfer comment.")
        else:
            lines.append("Use the exact amount. The unique atomic amount identifies this order; the transaction must reach the configured wallet.")
    return "\n".join(lines)


async def show_shop(message: Message, db: Database) -> None:
    categories = await db.list_categories()
    if not categories:
        products = await db.list_products()
        await message.answer("<b>HARRODS  ·  THE COLLECTION</b>\n<i>Discover something exceptional.</i>\n\nSelect an item to explore:", reply_markup=product_list(products))
        return
    await message.answer("<b>HARRODS  ·  THE COLLECTION</b>\n<i>Discover something exceptional.</i>\n\nChoose a category:", reply_markup=category_list(categories))


async def show_cart(message: Message, db: Database) -> None:
    lines = await db.get_cart(message.from_user.id)
    if not lines:
        await message.answer("<b>YOUR BASKET</b>\n\nYour basket is currently empty.\n<i>Find something you love in the collection.</i>", reply_markup=main_menu())
        return
    total = sum(line.line_total_gbp_pence for line in lines)
    body = ["<b>YOUR BASKET</b>", "<i>Your selected pieces</i>\n"]
    for line in lines:
        body.append(f"{line.quantity} × {line.product.name} — £{line.line_total_gbp_pence / 100:.2f}")
    body.append(f"\nSubtotal  ·  <b>£{total / 100:.2f}</b>")
    await message.answer("\n".join(body), reply_markup=cart_controls(lines))


@router.message(Command("start"))
@router.message(Command("shop"))
async def start(message: Message, db: Database, settings: Settings) -> None:
    if settings.mini_app_url:
        await message.answer("Open the premium mobile shop:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Open Shop", web_app=WebAppInfo(url=settings.mini_app_url))]]))
    await show_shop(message, db)


@router.message(Command("help"))
async def help_command(message: Message) -> None:
    await message.answer(
        "<b>HARRODS  ·  CUSTOMER CARE</b>\n\nExplore the collection, add your selections to the basket, then checkout with your delivery address. "
        "Choose TON, Bitcoin, or Litecoin when configured. Payment is accepted only after an on-chain verification."
    )


@router.message(Command("setphrase"))
async def set_phrase_command(message: Message, state: FSMContext) -> None:
    await state.set_state(SecurityState.market_phrase)
    await message.answer(
        "<b>Create your market security phrase</b>\n\n"
        "Send a phrase you can recognize, 8–128 characters. Do not use your Telegram password, wallet seed, recovery phrase, or a phrase you use elsewhere.\n\n"
        "The phrase will be encrypted in the shop database. Never send it to support, an admin, a payment agent, or another bot."
    )


@router.message(SecurityState.market_phrase)
async def save_market_phrase(message: Message, state: FSMContext, db: Database, settings: Settings) -> None:
    try:
        phrase = normalize_phrase(message.text or "")
    except ValueError as exc:
        await message.answer(str(exc))
        return
    await db.set_market_phrase(message.from_user.id, phrase, settings.telegram_bot_token)
    await state.clear()
    await message.answer(
        "Your market security phrase is saved. To verify that you are speaking with this genuine bot, use /verify_market and compare the phrase with the one you created."
    )


@router.message(Command("verify_market"))
async def verify_market_command(message: Message, db: Database, settings: Settings) -> None:
    record = await db.get_market_phrase(message.from_user.id)
    if not record:
        await message.answer("You have not created a market security phrase yet. Use /setphrase first.")
        return
    try:
        phrase = decrypt_phrase(record.encrypted_phrase, settings.telegram_bot_token)
    except ValueError:
        await message.answer("Your market phrase is unavailable because the bot secret changed. Please create a new phrase with /setphrase.")
        return
    await message.answer(
        f"<b>Market verification</b>\n\nYour private phrase is:\n<code>{phrase}</code>\n\n"
        "Only trust this phrase when it is shown by the exact official bot account you verified. Never reveal it to another bot or website."
    )


@router.callback_query(F.data == "shop")
async def shop_callback(callback: CallbackQuery, db: Database) -> None:
    await callback.answer()
    await show_shop(callback.message, db)


@router.callback_query(F.data.startswith("cat:"))
async def category_callback(callback: CallbackQuery, db: Database) -> None:
    category_id = int(callback.data.split(":", 1)[1])
    category = await db.get_category(category_id)
    if not category:
        await callback.answer("Category not found.", show_alert=True)
        return
    await callback.answer()
    children = await db.list_categories(parent_id=category_id)
    if children:
        await callback.message.answer(f"<b>{category.name}</b>\n\nChoose a collection:", reply_markup=category_list(children, parent_id=category_id))
        return
    products = await db.list_products(category_id=category_id)
    await callback.message.answer(f"<b>{category.name}</b>\n\nChoose an item:", reply_markup=product_list(products, category_id=category_id))


@router.callback_query(F.data == "help")
async def help_callback(callback: CallbackQuery) -> None:
    await callback.answer()
    await callback.message.answer(
        "<b>HARRODS  ·  CUSTOMER CARE</b>\n\nExplore the collection, add your selections to the basket, then checkout with your delivery address. "
        "Choose TON, Bitcoin, or Litecoin when configured. Payment is accepted only after an on-chain verification."
    )


@router.callback_query(F.data.startswith("product:"))
async def product_callback(callback: CallbackQuery, db: Database) -> None:
    await callback.answer()
    product = await db.get_product(int(callback.data.split(":", 1)[1]))
    if not product:
        await callback.message.answer("This product is no longer available.")
        return
    display_price = f"£{product.price_gbp_pence / 100:.2f}" if product.price_gbp_pence > 0 else "GBP price pending"
    caption = f"<b>HARRODS  ·  {product.name}</b>\n\n{product.description}\n\n<b>{display_price}</b>\n<i>{'In stock' if product.available_stock > 0 and product.price_gbp_pence > 0 else 'Currently unavailable'}</i>"
    keyboard = product_detail(product.id, product.available_stock)
    if product.image_url:
        try:
            await callback.message.answer_photo(product.image_url, caption=caption, reply_markup=keyboard)
            return
        except Exception:
            pass
    await callback.message.answer(caption, reply_markup=keyboard)


@router.callback_query(F.data.startswith("add:"))
async def add_callback(callback: CallbackQuery, db: Database) -> None:
    product_id = int(callback.data.split(":", 1)[1])
    ok, note = await db.change_cart(callback.from_user.id, product_id, 1)
    await callback.answer(note, show_alert=not ok)
    if ok:
        await show_cart(callback.message, db)


@router.callback_query(F.data == "cart")
async def cart_callback(callback: CallbackQuery, db: Database) -> None:
    await callback.answer()
    await show_cart(callback.message, db)


@router.callback_query(F.data.startswith("inc:"))
@router.callback_query(F.data.startswith("dec:"))
async def cart_quantity_callback(callback: CallbackQuery, db: Database) -> None:
    action, value = callback.data.split(":", 1)
    delta = 1 if action == "inc" else -1
    ok, note = await db.change_cart(callback.from_user.id, int(value), delta)
    await callback.answer(note, show_alert=not ok)
    await show_cart(callback.message, db)


@router.callback_query(F.data == "clear_cart")
async def clear_cart_callback(callback: CallbackQuery, db: Database) -> None:
    await db.clear_cart(callback.from_user.id)
    await callback.answer("Cart cleared")
    await show_cart(callback.message, db)


@router.callback_query(F.data == "checkout")
async def checkout_callback(callback: CallbackQuery, state: FSMContext, db: Database, settings: Settings) -> None:
    lines = await db.get_cart(callback.from_user.id)
    methods = enabled_methods(settings)
    if not lines:
        await callback.answer("Your cart is empty.", show_alert=True)
        return
    if not methods:
        await callback.answer("No payment methods are configured yet.", show_alert=True)
        return
    await callback.answer()
    await state.set_state(CheckoutState.payment_method)
    await callback.message.answer("<b>CHECKOUT</b>\n\nChoose your preferred payment method:", reply_markup=payment_method_controls(methods))


@router.callback_query(F.data.startswith("method:"))
async def select_payment_method(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    method = callback.data.split(":", 1)[1]
    if method not in enabled_methods(settings):
        await callback.answer("That payment method is not configured.", show_alert=True)
        return
    await callback.answer()
    await state.update_data(payment_method=method)
    await state.set_state(CheckoutState.address)
    await callback.message.answer("<b>DELIVERY DETAILS</b>\n\nPlease send your full delivery address in one message.\n<i>Use /cancel if you would like to stop.</i>")


@router.message(CheckoutState.address)
async def receive_address(message: Message, state: FSMContext, db: Database, payments: MultiChainPayments, settings: Settings) -> None:
    address = (message.text or "").strip()
    if len(address) < 10 or len(address) > 500:
        await message.answer("Please send a complete address between 10 and 500 characters.")
        return
    data = await state.get_data()
    method = str(data.get("payment_method", "ton"))
    lines = await db.get_cart(message.from_user.id)
    total_gbp_pence = sum(line.line_total_gbp_pence for line in lines)
    try:
        quote = await payments.quote(total_gbp_pence, method)
        order = await db.create_order(
            message.from_user.id,
            address,
            payment_method=quote.method,
            payment_amount_atomic=quote.amount_atomic,
            payment_symbol=quote.symbol,
            payment_expires_at=quote.expires_at,
        )
    except ValueError as exc:
        await state.clear()
        await message.answer(str(exc), reply_markup=main_menu())
        return
    except Exception:
        await message.answer("The live crypto quote is temporarily unavailable. Please try again or choose another payment method.")
        return
    await state.clear()
    await message.answer(await order_text(order, settings), reply_markup=payment_controls(order.id))


@router.callback_query(F.data.startswith("pay:"))
async def payment_callback(callback: CallbackQuery, state: FSMContext, db: Database) -> None:
    order_id = int(callback.data.split(":", 1)[1])
    order = await db.get_order(order_id, callback.from_user.id)
    if not order:
        await callback.answer("Order not found.", show_alert=True)
        return
    if order.payment_status == "paid":
        await callback.answer("Already verified.", show_alert=True)
        return
    await callback.answer()
    await state.set_state(PaymentState.transaction_hash)
    await state.update_data(order_id=order.id)
    await callback.message.answer(f"Send the {order.payment_symbol} transaction ID. An ID alone is not accepted; the bot will verify the real blockchain transaction.")


@router.message(Command("pay"))
async def payment_command(message: Message, command: CommandObject, state: FSMContext, db: Database) -> None:
    args = (command.args or "").split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer("Use /pay ORDER_ID, then send the transaction ID.")
        return
    order = await db.get_order(int(args[0]), message.from_user.id)
    if not order:
        await message.answer("Order not found.")
        return
    await state.set_state(PaymentState.transaction_hash)
    await state.update_data(order_id=order.id)
    await message.answer(f"Send the {order.payment_symbol} transaction ID for this order.")


@router.message(PaymentState.transaction_hash)
async def receive_payment_hash(message: Message, state: FSMContext, db: Database, payments: MultiChainPayments, bot: Bot, settings: Settings) -> None:
    txid = (message.text or "").strip()
    data = await state.get_data()
    order = await db.get_order(int(data.get("order_id", 0)), message.from_user.id)
    if not order:
        await state.clear()
        await message.answer("Order not found.")
        return
    result = await payments.verify_hash(order, txid)
    if not result.ok:
        await message.answer("Payment is not verified yet. Check the transaction ID and exact amount, then try again. The transaction must be confirmed and sent to the configured wallet.")
        return
    saved, reason = await db.mark_paid(order.id, result.tx_hash or txid)
    await state.clear()
    if not saved:
        await message.answer(f"Payment could not be recorded: {reason}")
        return
    refreshed = await db.get_order(order.id, message.from_user.id)
    await message.answer(f"Payment verified on-chain.\n\n{await order_text(refreshed or order, settings)}", reply_markup=main_menu())
    try:
        await bot.send_message(settings.admin_telegram_id, f"{order.payment_symbol} payment verified for order #{order.id}.")
    except Exception:
        pass


@router.message(Command("orders"))
async def orders_command(message: Message, db: Database) -> None:
    orders = await db.list_user_orders(message.from_user.id)
    if not orders:
        await message.answer("You have no orders yet.", reply_markup=main_menu())
        return
    await message.answer("<b>Your orders</b>\n\n" + "\n".join(
        f"#{order.id} · {format_atomic(order.payment_amount_atomic, order.payment_symbol)} {order.payment_symbol} · {order.status.replace('_', ' ')} · {order.payment_status}" for order in orders
    ), reply_markup=main_menu())


@router.callback_query(F.data == "orders")
async def orders_callback(callback: CallbackQuery, db: Database) -> None:
    await callback.answer()
    await orders_command(callback.message, db)


@router.message(Command("cart"))
async def cart_command(message: Message, db: Database) -> None:
    await show_cart(message, db)


@router.message(Command("cancel"))
async def cancel_command(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Current action cancelled.", reply_markup=main_menu())
