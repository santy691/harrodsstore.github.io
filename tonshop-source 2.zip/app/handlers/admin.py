from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo

from ..config import Settings
from ..db import Database
from ..keyboards import admin_menu, admin_order_controls
from ..states import AdminProductState
from ..crypto import format_atomic
from decimal import Decimal, InvalidOperation

router = Router()


def authorized(user_id: int, settings: Settings) -> bool:
    return user_id == settings.admin_telegram_id


def parse_product_fields(text: str) -> tuple[str, str, str | None, int, int]:
    fields = [item.strip() for item in text.split("|")]
    if len(fields) != 5:
        raise ValueError("Use: name | description | price_gbp | stock | image_url")
    name, description, price, stock, image_url = fields
    if not name or not description:
        raise ValueError("Name and description are required.")
    try:
        price_decimal = Decimal(price)
        cents = price_decimal * 100
        if cents != cents.to_integral_value():
            raise ValueError
        price_gbp_pence = int(cents)
        stock_int = int(stock)
    except (ValueError, TypeError, InvalidOperation):
        raise ValueError("Price must be GBP and stock must be a whole number.")
    if price_gbp_pence <= 0 or stock_int < 0:
        raise ValueError("GBP price must be positive and stock cannot be negative.")
    return name[:120], description[:1000], image_url or None, price_gbp_pence, stock_int


async def require_admin(message: Message, settings: Settings) -> bool:
    if not authorized(message.from_user.id, settings):
        await message.answer("This area is restricted.")
        return False
    return True


@router.message(Command("admin"))
async def admin_command(message: Message, settings: Settings) -> None:
    if await require_admin(message, settings):
        if settings.admin_app_url:
            await message.answer("<b>Admin panel</b>", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Open Admin Dashboard", web_app=WebAppInfo(url=settings.admin_app_url))]]))
        await message.answer("<b>Telegram admin controls</b>", reply_markup=admin_menu())


@router.callback_query(F.data == "adm:add")
async def admin_add_start(callback: CallbackQuery, state: FSMContext, settings: Settings) -> None:
    if not authorized(callback.from_user.id, settings):
        await callback.answer("Restricted", show_alert=True)
        return
    await callback.answer()
    await state.set_state(AdminProductState.add_fields)
    await callback.message.answer("Send: name | description | price_gbp | stock | image_url\nExample: Canvas Tote | Heavy cotton tote bag | 24.99 | 12 | https://example.com/tote.jpg")


@router.message(AdminProductState.add_fields)
async def admin_add_product(message: Message, state: FSMContext, db: Database, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    try:
        name, description, image_url, price_gbp_pence, stock = parse_product_fields(message.text or "")
        product_id = await db.add_product(name, description, image_url, price_gbp_pence, stock)
    except ValueError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    await message.answer(f"Product #{product_id} added.", reply_markup=admin_menu())


@router.callback_query(F.data == "adm:list")
async def admin_list_products(callback: CallbackQuery, db: Database, settings: Settings) -> None:
    if not authorized(callback.from_user.id, settings):
        await callback.answer("Restricted", show_alert=True)
        return
    await callback.answer()
    products = await db.list_products(include_inactive=True)
    if not products:
        await callback.message.answer("No products yet.")
        return
    await callback.message.answer("<b>Products</b>\n\n" + "\n".join(
        f"#{p.id} · {p.name} · £{p.price_gbp_pence / 100:.2f} · stock {p.stock} (reserved {p.reserved_stock})" for p in products
    ) + "\n\nEdit: /admin_edit ID\nStock: /admin_stock ID QUANTITY\nDelete: /admin_delete ID")


@router.message(Command("admin_edit"))
async def admin_edit_start(message: Message, command: CommandObject, state: FSMContext, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    args = (command.args or "").split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer("Use /admin_edit PRODUCT_ID")
        return
    await state.set_state(AdminProductState.edit_fields)
    await state.update_data(product_id=int(args[0]))
    await message.answer("Send the replacement fields: name | description | price_gbp | stock | image_url")


@router.message(AdminProductState.edit_fields)
async def admin_edit_product(message: Message, state: FSMContext, db: Database, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    data = await state.get_data()
    try:
        name, description, image_url, price_gbp_pence, stock = parse_product_fields(message.text or "")
        updated = await db.edit_product(int(data["product_id"]), name, description, image_url, price_gbp_pence, stock)
    except ValueError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    await message.answer("Product updated." if updated else "Update rejected. Check the ID and ensure stock is not below reserved stock.", reply_markup=admin_menu())


@router.message(Command("admin_delete"))
async def admin_delete_product(message: Message, command: CommandObject, db: Database, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    args = (command.args or "").split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer("Use /admin_delete PRODUCT_ID")
        return
    deleted = await db.delete_product(int(args[0]))
    await message.answer("Product archived." if deleted else "Delete rejected. It may not exist or have reserved stock.")


@router.message(Command("admin_stock"))
async def admin_set_stock(message: Message, command: CommandObject, db: Database, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    args = (command.args or "").split()
    if len(args) != 2 or not all(item.isdigit() for item in args):
        await message.answer("Use /admin_stock PRODUCT_ID QUANTITY")
        return
    updated = await db.set_stock(int(args[0]), int(args[1]))
    await message.answer("Inventory updated." if updated else "Inventory update rejected; check reserved stock.")


@router.callback_query(F.data == "adm:orders")
async def admin_orders(callback: CallbackQuery, db: Database, settings: Settings) -> None:
    if not authorized(callback.from_user.id, settings):
        await callback.answer("Restricted", show_alert=True)
        return
    await callback.answer()
    orders = await db.list_recent_orders()
    if not orders:
        await callback.message.answer("No orders yet.")
        return
    await callback.message.answer("<b>Recent orders</b>\n\n" + "\n".join(
        f"#{order.id} · user {order.user_id} · £{order.total_nano / 100:.2f} → {format_atomic(order.payment_amount_atomic, order.payment_symbol)} {order.payment_symbol} · {order.status} · {order.payment_status}" for order in orders
    ))
    for order in orders[:10]:
        await callback.message.answer(f"Order #{order.id}: {order.status} / {order.payment_status}", reply_markup=admin_order_controls(order.id))


@router.callback_query(F.data.startswith("adm_status:"))
async def admin_status(callback: CallbackQuery, db: Database, settings: Settings) -> None:
    if not authorized(callback.from_user.id, settings):
        await callback.answer("Restricted", show_alert=True)
        return
    _, order_id, status = callback.data.split(":", 2)
    updated = await db.set_order_status(int(order_id), status)
    await callback.answer("Updated" if updated else "Could not update", show_alert=not updated)
    if updated:
        await callback.message.edit_text(f"Order #{order_id} status: {status}")
