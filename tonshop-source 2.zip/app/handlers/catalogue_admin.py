from __future__ import annotations

import csv
import io
from decimal import Decimal, InvalidOperation

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, Message

from ..catalogue import csv_headers
from ..config import Settings
from ..db import Database
from ..states import AdminProductState
from .admin import require_admin

router = Router()


def parse_csv_row(row: dict[str, str]) -> dict[str, object]:
    price = Decimal((row.get("price_gbp") or "0").strip())
    cents = price * 100
    if cents != cents.to_integral_value() or cents <= 0:
        raise ValueError("price_gbp must be a positive GBP amount with at most two decimals")
    stock = int((row.get("stock") or "0").strip())
    if stock < 0:
        raise ValueError("stock cannot be negative")
    return {
        "sku": (row.get("sku") or "").strip(),
        "name": (row.get("name") or "").strip(),
        "description": (row.get("description") or "").strip(),
        "category": (row.get("category") or "Miscellaneous").strip(),
        "subcategory": (row.get("subcategory") or "Useful Finds").strip(),
        "price_gbp_pence": int(cents),
        "stock": stock,
        "image_url": (row.get("image_url") or "").strip(),
        "active": int((row.get("active") or "1").strip()),
        "featured": int((row.get("featured") or "0").strip()),
    }


@router.message(Command("admin_template"))
async def admin_template(message: Message, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=csv_headers())
    writer.writeheader()
    writer.writerow({"id": "", "sku": "CUSTOM-001", "name": "Example Product", "description": "Replace this description", "category": "Essentials", "subcategory": "Daily Essentials", "price_gbp": "24.99", "stock": "10", "image_url": "", "active": "1", "featured": "0"})
    await message.answer_document(BufferedInputFile(output.getvalue().encode(), filename="catalogue-template.csv"), caption="Edit this CSV and use /admin_import to load it. Existing rows are matched by SKU.")


@router.message(Command("admin_export"))
async def admin_export(message: Message, db: Database, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    rows = await db.export_catalogue_rows()
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=csv_headers())
    writer.writeheader()
    writer.writerows(rows)
    await message.answer_document(BufferedInputFile(output.getvalue().encode(), filename="catalogue-export.csv"), caption=f"Exported {len(rows)} products.")


@router.message(Command("admin_import"))
async def admin_import_start(message: Message, state: FSMContext, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    await state.set_state(AdminProductState.import_csv)
    await message.answer("Upload a CSV file using the template from /admin_template. Existing products are matched by SKU; blank or invalid rows are skipped and reported.")


@router.message(AdminProductState.import_csv, F.document)
async def admin_import_file(message: Message, state: FSMContext, db: Database, bot: Bot, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    document = message.document
    if not document.file_name.lower().endswith(".csv"):
        await message.answer("Please upload a .csv file.")
        return
    file = await bot.get_file(document.file_id)
    buffer = io.BytesIO()
    await bot.download_file(file.file_path, destination=buffer)
    buffer.seek(0)
    reader = csv.DictReader(io.TextIOWrapper(buffer, encoding="utf-8-sig"))
    required = set(csv_headers()) - {"id"}
    if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
        await message.answer("CSV headers do not match the template. Download a fresh template with /admin_template.")
        return
    imported = 0
    errors: list[str] = []
    for line_no, row in enumerate(reader, start=2):
        try:
            parsed = parse_csv_row(row)
            if not parsed["sku"] or not parsed["name"] or not parsed["description"]:
                raise ValueError("sku, name, and description are required")
            await db.upsert_catalogue_row(parsed)
            imported += 1
        except (ValueError, InvalidOperation, TypeError) as exc:
            errors.append(f"line {line_no}: {exc}")
    await state.clear()
    report = f"Imported {imported} products."
    if errors:
        report += "\nSkipped:\n" + "\n".join(errors[:15])
    await message.answer(report)


@router.message(Command("admin_category_add"))
async def admin_category_add(message: Message, command: CommandObject, db: Database, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    text = (command.args or "").strip()
    if not text:
        await message.answer("Use /admin_category_add CATEGORY | optional parent category")
        return
    fields = [part.strip() for part in text.split("|", 1)]
    parent_id = None
    if len(fields) == 2 and fields[1]:
        parent = next((item for item in await db.list_categories() if item.name.casefold() == fields[1].casefold()), None)
        if not parent:
            await message.answer("Parent category not found. Use the exact root category name.")
            return
        parent_id = parent.id
    category_id = await db.ensure_category(fields[0], parent_id)
    await message.answer(f"Category #{category_id} is ready.")


@router.message(Command("admin_category_rename"))
async def admin_category_rename(message: Message, command: CommandObject, db: Database, settings: Settings) -> None:
    if not await require_admin(message, settings):
        return
    fields = [part.strip() for part in (command.args or "").split(" ", 1)]
    if len(fields) != 2 or not fields[0].isdigit() or not fields[1]:
        await message.answer("Use /admin_category_rename CATEGORY_ID New Name")
        return
    updated = await db.rename_category(int(fields[0]), fields[1])
    await message.answer("Category renamed." if updated else "Category not found.")
