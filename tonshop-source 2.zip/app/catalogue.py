from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator
from urllib.parse import quote

PLACEHOLDER_IMAGE_BASE = "https://placehold.co/800x600/0B3928/C9A45C/png?text="

CATEGORY_GROUPS: dict[str, tuple[str, ...]] = {
    "Featured Products": ("Editor’s Picks", "Customer Favourites", "Staff Picks"),
    "New Arrivals": ("Just In", "This Month", "Limited First Look"),
    "Best Sellers": ("Most Loved", "Trending Now", "Repeat Favourites"),
    "Accessories": ("Bags & Pouches", "Jewellery", "Small Accessories"),
    "Clothing": ("Everyday Wear", "Outerwear", "Lounge & Basics"),
    "Footwear": ("Everyday Shoes", "Seasonal Footwear", "Comfort Styles"),
    "Electronics": ("Desk Electronics", "Audio Accessories", "Smart Essentials"),
    "Home & Living": ("Decor", "Kitchen & Dining", "Organisation"),
    "Beauty & Personal Care": ("Skincare Tools", "Bath & Body", "Self Care"),
    "Sports & Fitness": ("Training", "Recovery", "Outdoor Exercise"),
    "Outdoor & Travel": ("Travel Accessories", "Day Trips", "Outdoor Utility"),
    "Gifts": ("Gifts Under £25", "Thoughtful Gifts", "Gift Sets"),
    "Premium Collection": ("Signature Pieces", "Elevated Essentials", "Collector’s Edit"),
    "Seasonal Products": ("Spring Edit", "Summer Edit", "Winter Edit"),
    "Clearance": ("Last Chance", "Final Sizes", "Outlet Edit"),
    "Collectibles": ("Desk Collectibles", "Display Pieces", "Curiosity Cabinet"),
    "Gadgets": ("Everyday Gadgets", "Travel Gadgets", "Desk Gadgets"),
    "Lifestyle": ("Daily Rituals", "Work & Study", "Leisure"),
    "Essentials": ("Daily Essentials", "Reliable Basics", "Useful Things"),
    "Miscellaneous": ("Useful Finds", "Small Discoveries", "Assorted Edit"),
}

@dataclass(frozen=True, slots=True)
class SeedProduct:
    category: str
    subcategory: str
    name: str
    description: str
    price_gbp_pence: int
    stock: int
    sku: str
    image_url: str
    featured: bool


def placeholder_image(sku: str) -> str:
    return PLACEHOLDER_IMAGE_BASE + quote(sku)


def iter_seed_products() -> Iterator[SeedProduct]:
    number = 1
    names = ("Premium Item", "Signature Product", "Essential Product", "Curated Find")
    for category_index, (category, subcategories) in enumerate(CATEGORY_GROUPS.items(), start=1):
        for sub_index, subcategory in enumerate(subcategories, start=1):
            for item_index in range(1, 5):
                sku = f"PLACE-{number:04d}"
                name = f"{names[(item_index - 1) % len(names)]} {number:03d}"
                yield SeedProduct(
                    category=category,
                    subcategory=subcategory,
                    name=name,
                    description=f"Placeholder catalogue item for {subcategory}. Customise this description in the admin panel before publishing.",
                    price_gbp_pence=1299 + ((category_index * 7 + sub_index * 11 + item_index * 13) % 18000),
                    stock=8 + ((category_index + sub_index + item_index) % 24),
                    sku=sku,
                    image_url=placeholder_image(sku),
                    featured=(category_index <= 3 and item_index == 1),
                )
                number += 1


def csv_headers() -> list[str]:
    return ["id", "sku", "name", "description", "category", "subcategory", "price_gbp", "stock", "image_url", "active", "featured"]
