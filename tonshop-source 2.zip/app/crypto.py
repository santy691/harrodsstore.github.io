from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_UP
from typing import Any

import httpx

from .config import Settings
from .db import Order
from .ton import PaymentCheck, TonVerifier

SUPPORTED_METHODS = ("ton", "btc", "ltc")
COIN_IDS = {"ton": "the-open-network", "btc": "bitcoin", "ltc": "litecoin"}
SYMBOLS = {"ton": "TON", "btc": "BTC", "ltc": "LTC"}
ATOMIC_UNITS = {"ton": 1_000_000_000, "btc": 100_000_000, "ltc": 100_000_000}


@dataclass(slots=True)
class PaymentQuote:
    method: str
    symbol: str
    amount_atomic: int
    expires_at: str


def format_atomic(amount: int, symbol: str) -> str:
    decimals = 9 if symbol == "TON" else 8
    return f"{Decimal(amount) / Decimal(10**decimals):.{decimals}f}".rstrip("0").rstrip(".")


def payment_address(settings: Settings, method: str) -> str | None:
    return {
        "ton": settings.ton_wallet_address,
        "btc": settings.btc_wallet_address,
        "ltc": settings.ltc_wallet_address,
    }.get(method)


def enabled_methods(settings: Settings) -> list[str]:
    return [method for method in SUPPORTED_METHODS if payment_address(settings, method)]


class CryptoQuoteService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.base_url = settings.quote_api_base_url.rstrip("/")

    async def quote(self, total_gbp_pence: int, method: str) -> PaymentQuote:
        if method not in SUPPORTED_METHODS:
            raise ValueError("Unsupported payment method.")
        expires_at = (datetime.now(timezone.utc) + timedelta(minutes=self.settings.payment_quote_ttl_minutes)).isoformat()
        wallet = payment_address(self.settings, method)
        if not wallet:
            raise ValueError(f"{method.upper()} payments are not configured yet.")
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(
                f"{self.base_url}/simple/price",
                params={"ids": ",".join(COIN_IDS.values()), "vs_currencies": "gbp"},
            )
            response.raise_for_status()
            prices: dict[str, Any] = response.json()
        asset_gbp = Decimal(str(prices[COIN_IDS[method]]["gbp"]))
        gbp_total = Decimal(total_gbp_pence) / Decimal(100)
        base_atomic = int((gbp_total / asset_gbp * Decimal(ATOMIC_UNITS[method])).quantize(Decimal("1"), rounding=ROUND_UP))
        if base_atomic <= 0:
            raise ValueError("The live quote is too small for this payment network.")
        return PaymentQuote(method, SYMBOLS[method], base_atomic, expires_at)


class UtxoVerifier:
    def __init__(self, settings: Settings, method: str):
        self.settings = settings
        self.method = method
        self.wallet = payment_address(settings, method) or ""
        self.base_url = (settings.btc_api_base_url if method == "btc" else settings.ltc_api_base_url).rstrip("/")
        self.required_confirmations = settings.btc_required_confirmations if method == "btc" else settings.ltc_required_confirmations

    async def _get_json(self, path: str) -> Any:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(f"{self.base_url}{path}")
            response.raise_for_status()
            return response.json()

    @staticmethod
    def _output_addresses(output: dict[str, Any]) -> set[str]:
        addresses = set()
        if output.get("scriptpubkey_address"):
            addresses.add(str(output["scriptpubkey_address"]))
        for address in output.get("scriptpubkey_addresses") or []:
            addresses.add(str(address))
        return addresses

    def _amount_to_wallet(self, transaction: dict[str, Any]) -> int:
        return sum(
            int(output.get("value", 0))
            for output in transaction.get("vout", [])
            if self.wallet.lower() in {address.lower() for address in self._output_addresses(output)}
        )

    async def _check_transaction(self, order: Order, transaction: dict[str, Any], tip_height: int | None = None) -> PaymentCheck:
        if order.payment_method != self.method:
            return PaymentCheck(False, reason="payment method mismatch")
        if order.payment_expires_at:
            expires = datetime.fromisoformat(order.payment_expires_at)
            if datetime.now(timezone.utc) > expires:
                return PaymentCheck(False, reason="payment quote expired")
        txid = str(transaction.get("txid") or "").strip()
        if not re.fullmatch(r"[0-9a-fA-F]{64}", txid):
            return PaymentCheck(False, reason="invalid transaction ID")
        status = transaction.get("status") or {}
        if not status.get("confirmed"):
            return PaymentCheck(False, reason="transaction is not confirmed")
        block_height = status.get("block_height")
        if tip_height is None or block_height is None:
            return PaymentCheck(False, reason="confirmation height unavailable")
        confirmations = int(tip_height) - int(block_height) + 1
        if confirmations < self.required_confirmations:
            return PaymentCheck(False, reason="not enough confirmations")
        if self._amount_to_wallet(transaction) != order.payment_amount_atomic:
            return PaymentCheck(False, reason="amount or recipient mismatch")
        return PaymentCheck(True, tx_hash=txid, reason="verified")

    async def verify_hash(self, order: Order, txid: str) -> PaymentCheck:
        candidate = txid.strip()
        if not re.fullmatch(r"[0-9a-fA-F]{64}", candidate):
            return PaymentCheck(False, reason="invalid transaction ID format")
        try:
            transaction, tip_height = await asyncio.gather(
                self._get_json(f"/tx/{candidate}"),
                self._get_json("/blocks/tip/height"),
            )
            return await self._check_transaction(order, transaction, int(tip_height))
        except (httpx.HTTPError, ValueError, TypeError):
            return PaymentCheck(False, reason="blockchain lookup unavailable")

    async def find_matching_payment(self, order: Order) -> PaymentCheck:
        if not self.wallet:
            return PaymentCheck(False, reason="wallet not configured")
        try:
            transactions = await self._get_json(f"/address/{self.wallet}/txs")
            tip_height = int(await self._get_json("/blocks/tip/height"))
        except (httpx.HTTPError, ValueError, TypeError):
            return PaymentCheck(False, reason="blockchain lookup unavailable")
        for transaction in transactions:
            result = await self._check_transaction(order, transaction, tip_height)
            if result.ok:
                return result
        return PaymentCheck(False, reason="no verified payment yet")


class MultiChainPayments:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.quotes = CryptoQuoteService(settings)
        self.verifiers = {
            "ton": TonVerifier(settings),
            "btc": UtxoVerifier(settings, "btc"),
            "ltc": UtxoVerifier(settings, "ltc"),
        }

    async def quote(self, total_gbp_pence: int, method: str) -> PaymentQuote:
        return await self.quotes.quote(total_gbp_pence, method)

    async def verify_hash(self, order: Order, txid: str) -> PaymentCheck:
        verifier = self.verifiers.get(order.payment_method)
        if not verifier:
            return PaymentCheck(False, reason="unsupported payment method")
        return await verifier.verify_hash(order, txid)

    async def find_matching_payment(self, order: Order) -> PaymentCheck:
        verifier = self.verifiers.get(order.payment_method)
        if not verifier:
            return PaymentCheck(False, reason="unsupported payment method")
        return await verifier.find_matching_payment(order)
