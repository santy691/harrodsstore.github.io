from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from .db import Category


def main_menu() -> InlineKeyboardMarkup:
    """Premium, compact customer navigation for Telegram's native bot UI."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛍  Explore collection", callback_data="shop")],
        [InlineKeyboardButton(text="🛒  Basket", callback_data="cart"),
         InlineKeyboardButton(text="📦  My orders", callback_data="orders")],
        [InlineKeyboardButton(text="✦  Customer care", callback_data="help")],
    ])


def category_list(categories: list[Category], parent_id: int | None = None) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=f"✦ {category.name} ({category.product_count})", callback_data=f"cat:{category.id}")] for category in categories]
    if parent_id is not None:
        rows.append([InlineKeyboardButton(text="← Back to categories", callback_data="shop")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def category_products_footer(category_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="← Categories", callback_data="shop"), InlineKeyboardButton(text="🛒 Basket", callback_data="cart")],
    ])


def product_list(products, category_id: int | None = None) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(
        text=f"✦ {p.name}  ·  {f'£{p.price_gbp_pence / 100:.2f}' if p.price_gbp_pence > 0 else 'GBP price pending'}",
        callback_data=f"product:{p.id}",
    )] for p in products]
    rows.append([InlineKeyboardButton(text="🛒  View basket", callback_data="cart")])
    if category_id is not None:
        rows.append([InlineKeyboardButton(text="← Categories", callback_data="shop")])
    rows.append([InlineKeyboardButton(text="↻  Refresh collection", callback_data="shop")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def product_detail(product_id: int, available: int) -> InlineKeyboardMarkup:
    rows = []
    if available > 0:
        rows.append([InlineKeyboardButton(text="＋  Add to basket", callback_data=f"add:{product_id}")])
    else:
        rows.append([InlineKeyboardButton(text="Sold out", callback_data="shop")])
    rows.append([
        InlineKeyboardButton(text="🛒 Basket", callback_data="cart"),
        InlineKeyboardButton(text="← Collection", callback_data="shop"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def cart_controls(lines) -> InlineKeyboardMarkup:
    rows = []
    for line in lines:
        rows.append([
            InlineKeyboardButton(text="−", callback_data=f"dec:{line.product.id}"),
            InlineKeyboardButton(text=f"{line.quantity} × {line.product.name}", callback_data=f"product:{line.product.id}"),
            InlineKeyboardButton(text="+", callback_data=f"inc:{line.product.id}"),
        ])
    if lines:
        rows.append([InlineKeyboardButton(text="✓  Continue to checkout", callback_data="checkout")])
        rows.append([InlineKeyboardButton(text="Clear basket", callback_data="clear_cart")])
    rows.append([InlineKeyboardButton(text="← Continue shopping", callback_data="shop")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def payment_controls(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="↻  Check payment", callback_data=f"pay:{order_id}")],
        [InlineKeyboardButton(text="📦  My orders", callback_data="orders"),
         InlineKeyboardButton(text="🛍  Shop", callback_data="shop")],
    ])


def payment_method_controls(methods: list[str]) -> InlineKeyboardMarkup:
    labels = {"ton": "💎 TON", "btc": "₿ Bitcoin", "ltc": "Ł Litecoin"}
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=labels.get(method, method.upper()), callback_data=f"method:{method}")]
        for method in methods
    ])


def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="＋ Add product", callback_data="adm:add"),
         InlineKeyboardButton(text="Products", callback_data="adm:list")],
        [InlineKeyboardButton(text="Recent orders", callback_data="adm:orders")],
    ])


def admin_order_controls(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Processing", callback_data=f"adm_status:{order_id}:processing"),
         InlineKeyboardButton(text="Shipped", callback_data=f"adm_status:{order_id}:shipped")],
        [InlineKeyboardButton(text="Delivered", callback_data=f"adm_status:{order_id}:delivered"),
         InlineKeyboardButton(text="Cancelled", callback_data=f"adm_status:{order_id}:cancelled")],
    ])
