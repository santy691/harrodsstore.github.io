from __future__ import annotations

import hashlib
import hmac
import json
import mimetypes
import secrets
import time
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl

from aiohttp import web

from .config import Settings
from .crypto import MultiChainPayments, payment_address
from .db import Database


class WebAuthError(ValueError):
    pass


def validate_init_data(init_data: str | None, settings: Settings) -> int:
    if not init_data:
        raise WebAuthError("Telegram WebApp authentication is required.")
    values: dict[str, str] = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = values.pop("hash", "")
    if not received_hash or not values:
        raise WebAuthError("Invalid Telegram WebApp data.")
    auth_date = int(values.get("auth_date", "0"))
    if abs(int(time.time()) - auth_date) > 86400:
        raise WebAuthError("Expired Telegram WebApp data.")
    data_check_string = "\n".join(f"{key}={values[key]}" for key in sorted(values))
    secret_key = hmac.new(b"WebAppData", settings.telegram_bot_token.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise WebAuthError("Telegram WebApp signature check failed.")
    try:
        return int(json.loads(values["user"])["id"])
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise WebAuthError("Telegram user data is invalid.") from exc


def request_user(request: web.Request, settings: Settings, admin: bool = False) -> int:
    user_id = validate_init_data(request.headers.get("X-Telegram-Init-Data"), settings)
    if admin and user_id != settings.admin_telegram_id:
        raise WebForbidden("Administrator access required.")
    return user_id


class WebForbidden(WebAuthError):
    pass


def web_error(exc: Exception) -> web.Response:
    status = 403 if isinstance(exc, (WebAuthError, WebForbidden)) else 400
    return web.json_response({"ok": False, "error": str(exc)}, status=status)


def product_json(product: Any) -> dict[str, Any]:
    return {
        "id": product.id, "sku": product.sku, "name": product.name, "description": product.description,
        "price_gbp": product.price_gbp_pence / 100, "stock": product.available_stock,
        "image_url": product.image_url, "category_id": product.category_id,
        "subcategory_id": product.subcategory_id, "featured": product.featured,
    }


async def catalogue(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        request_user(request, settings)
        db: Database = request.app["db"]
        roots = await db.list_categories()
        categories = []
        for root in roots:
            children = await db.list_categories(parent_id=root.id)
            categories.append({"id": root.id, "name": root.name, "children": [{"id": c.id, "name": c.name} for c in children]})
        products = [product_json(p) for p in await db.list_products()]
        return web.json_response({"ok": True, "categories": categories, "products": products})
    except Exception as exc:
        return web_error(exc)


async def checkout(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        user_id = request_user(request, settings)
        payload = await request.json()
        address = str(payload.get("address", "")).strip()
        method = str(payload.get("payment_method", "")).lower().strip()
        items = payload.get("items", [])
        if len(address) < 10 or len(address) > 500 or not isinstance(items, list) or not items:
            raise ValueError("A delivery address and at least one product are required.")
        db: Database = request.app["db"]
        await db.clear_cart(user_id)
        for item in items:
            if not isinstance(item, dict):
                raise ValueError("Invalid basket item.")
            ok, note = await db.change_cart(user_id, int(item["product_id"]), int(item["quantity"]))
            if not ok:
                raise ValueError(note)
        lines = await db.get_cart(user_id)
        total = sum(line.line_total_gbp_pence for line in lines)
        payments: MultiChainPayments = request.app["payments"]
        quote = await payments.quote(total, method)
        order = await db.create_order(user_id, address, method, quote.amount_atomic, quote.symbol, quote.expires_at)
        return web.json_response({"ok": True, "order_id": order.id, "payment_symbol": quote.symbol, "amount_atomic": quote.amount_atomic, "amount_display": quote.display_amount, "payment_address": payment_address(settings, method), "reference": order.payment_reference, "expires_at": quote.expires_at})
    except Exception as exc:
        return web_error(exc)


async def admin_catalogue(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        request_user(request, settings, admin=True)
        db: Database = request.app["db"]
        return web.json_response({"ok": True, "categories": [{"id": category.id, "name": category.name, "parent_id": category.parent_id, "product_count": category.product_count} for category in await db.list_categories()], "products": await db.export_catalogue_rows()})
    except Exception as exc:
        return web_error(exc)


async def admin_product(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        request_user(request, settings, admin=True)
        payload = await request.json()
        db: Database = request.app["db"]
        name = str(payload["name"]).strip(); description = str(payload["description"]).strip()
        price = int(round(float(payload["price_gbp"]) * 100)); stock = int(payload["stock"])
        if not name or not description or price <= 0 or stock < 0:
            raise ValueError("Name, description, positive GBP price, and non-negative stock are required.")
        product_id = payload.get("id")
        if product_id:
            updated = await db.edit_product(int(product_id), name, description, payload.get("image_url") or None, price, stock, str(payload.get("sku") or ""), payload.get("category_id"), payload.get("subcategory_id"), bool(payload.get("featured", False)))
            if not updated:
                raise ValueError("Product update rejected. Check reserved stock.")
            await db.set_product_flags(int(product_id), bool(payload.get("active", True)), bool(payload.get("featured", False)))
            return web.json_response({"ok": True, "id": int(product_id)})
        new_id = await db.add_product(name, description, payload.get("image_url") or None, price, stock, str(payload.get("sku") or f"WEB-{secrets.token_hex(4).upper()}"), payload.get("category_id"), payload.get("subcategory_id"), bool(payload.get("featured", False)))
        return web.json_response({"ok": True, "id": new_id})
    except Exception as exc:
        return web_error(exc)


async def admin_category(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        request_user(request, settings, admin=True)
        payload = await request.json(); db: Database = request.app["db"]
        name = str(payload.get("name", "")).strip()
        if not name:
            raise ValueError("Category name is required.")
        if payload.get("id"):
            ok = await db.rename_category(int(payload["id"]), name)
            if not ok:
                raise ValueError("Category not found.")
            return web.json_response({"ok": True, "id": int(payload["id"])})
        category_id = await db.ensure_category(name, int(payload["parent_id"]) if payload.get("parent_id") else None)
        return web.json_response({"ok": True, "id": category_id})
    except Exception as exc:
        return web_error(exc)


async def admin_orders(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        request_user(request, settings, admin=True)
        orders = await request.app["db"].list_recent_orders()
        return web.json_response({"ok": True, "orders": [{"id": o.id, "user_id": o.user_id, "total_gbp": o.total_nano / 100, "payment_symbol": o.payment_symbol, "payment_amount": o.payment_amount_atomic, "status": o.status, "payment_status": o.payment_status, "created_at": o.created_at} for o in orders]})
    except Exception as exc:
        return web_error(exc)


async def admin_order_status(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        request_user(request, settings, admin=True)
        payload = await request.json(); status = str(payload.get("status", "")).strip()
        if status not in {"pending_payment", "paid", "processing", "shipped", "delivered", "cancelled"}:
            raise ValueError("Unsupported order status.")
        updated = await request.app["db"].set_order_status(int(payload["order_id"]), status)
        if not updated:
            raise ValueError("Order status could not be updated.")
        return web.json_response({"ok": True})
    except Exception as exc:
        return web_error(exc)


async def admin_upload(request: web.Request) -> web.Response:
    settings: Settings = request.app["settings"]
    try:
        request_user(request, settings, admin=True)
        reader = await request.multipart(); field = await reader.next()
        if field is None or field.name != "file":
            raise ValueError("Upload a file field named file.")
        content_type = field.headers.get("Content-Type", "")
        if not content_type.startswith("image/"):
            raise ValueError("Only image uploads are accepted.")
        upload_dir = Path(settings.db_path).parent / "uploads"; upload_dir.mkdir(parents=True, exist_ok=True)
        suffix = mimetypes.guess_extension(content_type) or ".bin"
        target = upload_dir / f"{secrets.token_hex(12)}{suffix}"
        size = 0
        with target.open("wb") as output:
            while chunk := await field.read_chunk():
                size += len(chunk)
                if size > 5 * 1024 * 1024:
                    target.unlink(missing_ok=True); raise ValueError("Images must be 5 MB or smaller.")
                output.write(chunk)
        return web.json_response({"ok": True, "url": f"/media/{target.name}"})
    except Exception as exc:
        return web_error(exc)


def setup_web_routes(app: web.Application, db: Database, payments: MultiChainPayments, settings: Settings) -> None:
    app["db"] = db; app["payments"] = payments; app["settings"] = settings
    root = Path(__file__).parent.parent / "static"
    upload_dir = Path(settings.db_path).parent / "uploads"; upload_dir.mkdir(parents=True, exist_ok=True)
    async def miniapp_page(_: web.Request) -> web.FileResponse:
        return web.FileResponse(root / "index.html")

    async def admin_page(_: web.Request) -> web.FileResponse:
        return web.FileResponse(root / "admin.html")

    app.router.add_get("/miniapp", miniapp_page)
    app.router.add_get("/admin-dashboard", admin_page)
    async def routes_manifest(_: web.Request) -> web.Response:
        return web.json_response({"routes": [{"path": "/miniapp", "title": "Shop"}, {"path": "/admin-dashboard", "title": "Admin dashboard"}]})
    app.router.add_get("/manus-routes.json", routes_manifest)
    app.router.add_static("/assets", root / "assets", show_index=False)
    app.router.add_static("/media", upload_dir, show_index=False)
    app.router.add_get("/api/miniapp/catalogue", catalogue)
    app.router.add_post("/api/miniapp/checkout", checkout)
    app.router.add_get("/api/admin/catalogue", admin_catalogue)
    app.router.add_post("/api/admin/product", admin_product)
    app.router.add_post("/api/admin/category", admin_category)
    app.router.add_get("/api/admin/orders", admin_orders)
    app.router.add_post("/api/admin/order-status", admin_order_status)
    app.router.add_post("/api/admin/upload", admin_upload)
