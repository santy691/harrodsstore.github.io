from aiogram.fsm.state import State, StatesGroup


class CheckoutState(StatesGroup):
    payment_method = State()
    address = State()


class PaymentState(StatesGroup):
    transaction_hash = State()


class SecurityState(StatesGroup):
    market_phrase = State()


class AdminProductState(StatesGroup):
    add_fields = State()
    edit_fields = State()
    import_csv = State()
    add_category = State()
